package com.example.medical.Dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MedicineDTO {
    private Long id;
    private String name;
    private String description;
    private String category;
    private String manufacturer;
    private double price;
    private String image;
    private int stock;
}

