package com.example.medical.Models;

import com.example.medical.Models.enums.OrderStatus;
import com.example.medical.Models.enums.User;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
public class Order extends BaseModel {
    @Enumerated(EnumType.ORDINAL)
    private User user;
    private Date date;
    @Enumerated(EnumType.ORDINAL)
    private OrderStatus status;
    private double totalPrice;
    @OneToMany(mappedBy = "order")
    private List<OrderItem> items;

}
