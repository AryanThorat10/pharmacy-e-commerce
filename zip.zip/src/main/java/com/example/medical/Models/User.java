package com.example.medical.Models;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
public class User extends BaseModel {
    private String username;
    private String password;
    private String email;
    private String name;
    private Address shippingAddress;
    private Address billingAddress;
    private List<Order> orderHistory;

}
