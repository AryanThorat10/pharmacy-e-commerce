package com.example.medical.Models;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;


@Getter
@Setter
@Entity
public class Medicine {

    @Id
    @GeneratedValue()
    private Long id;

    private String name;
    private String description;
    private String category;
    private String manufacturer;
    private double price;
    private String image;
    private int stock;

    // Constructors, getters, and setters

    public Medicine() {
    }

    public Medicine(String name, String description, String category, String manufacturer, double price, String image, int stock) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.manufacturer = manufacturer;
        this.price = price;
        this.image = image;
        this.stock = stock;
    }
}
