package com.example.medical.Models.enums;

public enum OrderStatus {
    Pending,
    Failed,
    OnTheWay,
    Delivered
}
