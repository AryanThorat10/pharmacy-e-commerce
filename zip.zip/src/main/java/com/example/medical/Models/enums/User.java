package com.example.medical.Models.enums;

public enum User {
    Admin,
    MedicalOwner,
    Customer

}
