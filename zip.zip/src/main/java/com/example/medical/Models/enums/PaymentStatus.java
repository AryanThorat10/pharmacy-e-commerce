package com.example.medical.Models.enums;

public enum PaymentStatus {
    Success,
    Failed,
    Pending

}
